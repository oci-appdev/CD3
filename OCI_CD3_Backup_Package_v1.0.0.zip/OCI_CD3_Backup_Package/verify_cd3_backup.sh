#!/usr/bin/env bash
# Verify the latest logical CD3 backup and all OCI volume backup records in its manifest.
set -Eeuo pipefail
umask 077

CONFIG_FILE="/etc/cd3-backup/cd3-backup.conf"
BACKUP_ID=""
BACKUP_CLASS_FILTER=""

usage() {
  cat <<'USAGE'
Usage: verify_cd3_backup.sh [--config FILE] [--backup-id ID] [--backup-class CLASS]

If no backup ID is supplied, the newest logical backup is selected by Object Storage creation time.
USAGE
}

die() { printf 'ERROR: %s\n' "$1" >&2; exit 1; }
is_true() { case "${1,,}" in true|yes|1) return 0 ;; *) return 1 ;; esac; }
sanitize_name() { printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9._-]+/-/g; s/^-+//; s/-+$//' | cut -c1-100; }

args=("$@")
for ((i=0; i<${#args[@]}; i++)); do
  case "${args[$i]}" in
    --config) ((i+1<${#args[@]})) || die "--config requires a file."; CONFIG_FILE="${args[$((i+1))]}"; ((i+=1)) ;;
    --backup-id) ((i+1<${#args[@]})) || die "--backup-id requires a value."; BACKUP_ID="${args[$((i+1))]}"; ((i+=1)) ;;
    --backup-class) ((i+1<${#args[@]})) || die "--backup-class requires a value."; BACKUP_CLASS_FILTER="${args[$((i+1))]}"; ((i+=1)) ;;
    --help|-h) usage; exit 0 ;;
    *) die "Unknown option: ${args[$i]}" ;;
  esac
done

[[ -r "$CONFIG_FILE" ]] || die "Configuration file is not readable: $CONFIG_FILE"
# shellcheck source=/dev/null
source "$CONFIG_FILE"
for cmd in oci jq curl sha256sum tar sort tail; do command -v "$cmd" >/dev/null 2>&1 || die "Required command not found: $cmd"; done

BACKUP_BUCKET="${BACKUP_BUCKET:-}"
OBJECT_PREFIX="${OBJECT_PREFIX:-cd3}"
OCI_REGION="${OCI_REGION:-}"
OCI_AUTH_MODE="${OCI_AUTH_MODE:-instance_principal}"
USE_REALM_SPECIFIC_ENDPOINT="${USE_REALM_SPECIFIC_ENDPOINT:-true}"
INSTANCE_BACKUP_NAME="${INSTANCE_BACKUP_NAME:-}"

metadata='{}'
if [[ -z "$OCI_REGION" || -z "$INSTANCE_BACKUP_NAME" ]]; then
  metadata="$(curl -fsS --connect-timeout 3 --max-time 10 -H 'Authorization: Bearer Oracle' 'http://169.254.169.254/opc/v2/instance/' 2>/dev/null || printf '{}')"
fi
OCI_REGION="${OCI_REGION:-$(jq -r '.canonicalRegionName // .region // empty' <<<"$metadata")}"
INSTANCE_BACKUP_NAME="${INSTANCE_BACKUP_NAME:-$(jq -r '.displayName // empty' <<<"$metadata")}"
INSTANCE_BACKUP_NAME="$(sanitize_name "$INSTANCE_BACKUP_NAME")"
[[ -n "$BACKUP_BUCKET" && -n "$OCI_REGION" && -n "$INSTANCE_BACKUP_NAME" ]] || die "BACKUP_BUCKET, OCI_REGION, and INSTANCE_BACKUP_NAME are required."

oci_cmd() {
  local command=(oci "$@")
  [[ -z "$OCI_AUTH_MODE" ]] || command+=(--auth "$OCI_AUTH_MODE")
  command+=(--region "$OCI_REGION")
  is_true "$USE_REALM_SPECIFIC_ENDPOINT" && command+=(--realm-specific-endpoint)
  "${command[@]}"
}

temp_dir="$(mktemp -d)"
trap 'rm -rf -- "$temp_dir"' EXIT
root_prefix="$OBJECT_PREFIX/$INSTANCE_BACKUP_NAME/"
oci_cmd os object list --bucket-name "$BACKUP_BUCKET" --prefix "$root_prefix" --all >"$temp_dir/objects.json"

selection_filter='select(.name | endswith("/cd3-backup.tar.gz"))'
if [[ -n "$BACKUP_ID" ]]; then
  selection_filter="$selection_filter | select(.name | contains(\"/$BACKUP_ID/\"))"
fi
if [[ -n "$BACKUP_CLASS_FILTER" ]]; then
  selection_filter="$selection_filter | select(.name | contains(\"/$BACKUP_CLASS_FILTER/\"))"
fi
archive_object="$(jq -r ".data.objects[]? | $selection_filter | [(.\"time-created\" // \"\"), .name] | @tsv" "$temp_dir/objects.json" | sort | tail -1 | cut -f2-)"
[[ -n "$archive_object" ]] || die "No matching logical CD3 backup was found."
object_dir="${archive_object%/*}"

printf 'Verifying: %s\n' "$archive_object"
oci_cmd os object get --bucket-name "$BACKUP_BUCKET" --name "$archive_object" --file "$temp_dir/cd3-backup.tar.gz"
oci_cmd os object get --bucket-name "$BACKUP_BUCKET" --name "$object_dir/SHA256SUMS" --file "$temp_dir/SHA256SUMS"
oci_cmd os object get --bucket-name "$BACKUP_BUCKET" --name "$object_dir/backup-manifest.json" --file "$temp_dir/backup-manifest.json"
(cd "$temp_dir" && sha256sum -c SHA256SUMS)

archive_listing="$temp_dir/archive-listing.txt"
tar -tzf "$temp_dir/cd3-backup.tar.gz" >"$archive_listing"
grep -qx 'backup-metadata/backup-manifest.json' "$archive_listing" || die "Archive is missing its internal backup manifest."
grep -qx 'backup-metadata/inventory/instance.json' "$archive_listing" || die "Archive is missing the instance inventory."

mapfile -t backup_records < <(jq -c '.storage.volumeBackups[]?' "$temp_dir/backup-manifest.json")
for record in "${backup_records[@]}"; do
  backup_type="$(jq -r '.type' <<<"$record")"
  backup_ocid="$(jq -r '.id' <<<"$record")"
  case "$backup_type" in
    volume-group-backup) response="$(oci_cmd bv volume-group-backup get --volume-group-backup-id "$backup_ocid")" ;;
    boot-volume-backup) response="$(oci_cmd bv boot-volume-backup get --boot-volume-backup-id "$backup_ocid")" ;;
    volume-backup) response="$(oci_cmd bv backup get --volume-backup-id "$backup_ocid")" ;;
    *) die "Unknown backup type in manifest: $backup_type" ;;
  esac
  state="$(jq -r '.data."lifecycle-state" // empty' <<<"$response")"
  [[ "$state" == "AVAILABLE" ]] || die "$backup_ocid is not AVAILABLE; current state: $state"
  printf 'OCI %s AVAILABLE: %s\n' "$backup_type" "$backup_ocid"
done

printf 'Backup verification PASSED.\n'
printf 'Backup ID: %s\n' "$(jq -r '.backupId' "$temp_dir/backup-manifest.json")"

